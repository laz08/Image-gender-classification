Extract here the photos of Faces in the wild
in a subfolder "lfw-deepfunneled".

Then you can execute extractPictures.sh:

$ extractPictures.sh